<?php

namespace App\Models;

use CodeIgniter\Model;

class LoginModal extends Model
{
    protected $table = 'news';

    public function getData($slug = false)
    {
        // if ($slug === false) {
        //     return $this->findAll();
        // }

        // return $this->asArray()
        //     ->where(['slug' => $slug])
        //     ->first();

        return ['OK'=> 'ok', 1];
    }
}
