<?php

namespace App\Controllers;
use App\Models\LoginModal;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
class Login extends ResourceController
{
    use ResponseTrait;
    protected $modelName = 'App\Models\Login';
    protected $format    = 'json';

    public function index()
    {
        

        $model = new LoginModal();

        $data = [
            'news'  => $model->getData(),
            'title' => 'News archive',
        ];

        return $data;
        return view('login/login', $this->model->findAll());
        return $this->respond($this->model->findAll());
    }

    public function create()
    {

        $model = new LoginModal();

        $data = [
            'news'  => 'ok',
            'title' => 'News archive',
        ];
        return $this->respond($data, 200);
        return $this->respondCreated();
        return $data;
        return view('login/login', $this->model->findAll());
        return $this->respond($this->model->findAll());
    }

    // ...
}
